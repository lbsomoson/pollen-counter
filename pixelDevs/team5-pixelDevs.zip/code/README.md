# pixelDevs_Hackathon

## Core Contributors
- Lead Ded: Ma. Zeit Elizha Tomboc (T1L) [@zptomboc](https://github.com/zptomboc)
- Image Proc Dev: Arni Laureen Gabrielle Mendoza (T4L) [@arni-laureen](https://github.com/arni-laureen)
- GUI Dev: Lea Marie Somoson (T2L) [@xxyangxx](https://github.com/xxyangxx)

## Guidelines
1. Install dependencies using the `pip install -r requirements.txt` or `pip install -r requirements` command.
2. Run the application `python GUI.py`.